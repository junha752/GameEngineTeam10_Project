// Copyright Epic Games, Inc. All Rights Reserved.

#include "GameEnTeam10_Project.h"
#include "Modules/ModuleManager.h"

IMPLEMENT_PRIMARY_GAME_MODULE( FDefaultGameModuleImpl, GameEnTeam10_Project, "GameEnTeam10_Project" );
