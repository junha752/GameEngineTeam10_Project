#pragma once

#include "CoreMinimal.h"
#include "Blueprint/UserWidget.h"
#include "TurnWidget.generated.h"

UCLASS()
class GAMEENTEAM10_PROJECT_API UTurnWidget : public UUserWidget
{
    GENERATED_BODY()

public:
    virtual void NativeConstruct() override;

    // ���� �� ���� �Լ�
    UFUNCTION(BlueprintCallable)
    void SetRemainingTurns(int32 InTurns);

protected:
    // ���� �� ǥ�� �ؽ�Ʈ
    UPROPERTY(meta = (BindWidget))
    class UTextBlock* Txt_TurnCount;

    // ��ư 6��
    UPROPERTY(meta = (BindWidgetOptional)) class UButton* Btn_EquipBuy;
    UPROPERTY(meta = (BindWidgetOptional)) class UButton* Btn_Repair;
    UPROPERTY(meta = (BindWidgetOptional)) class UButton* Btn_Rest;
    UPROPERTY(meta = (BindWidgetOptional)) class UButton* Btn_SwordTraining;
    UPROPERTY(meta = (BindWidgetOptional)) class UButton* Btn_MagicPractice;
    UPROPERTY(meta = (BindWidgetOptional)) class UButton* Btn_MagicStudy;

    // �� ��ư ���� �ؽ�Ʈ (�̸� + �ϼ�)
    UPROPERTY(meta = (BindWidgetOptional)) class UTextBlock* Txt_EquipBuy;
    UPROPERTY(meta = (BindWidgetOptional)) class UTextBlock* Txt_EquipBuyCount;

    UPROPERTY(meta = (BindWidgetOptional)) class UTextBlock* Txt_Repair;
    UPROPERTY(meta = (BindWidgetOptional)) class UTextBlock* Txt_RepairCount;

    UPROPERTY(meta = (BindWidgetOptional)) class UTextBlock* Txt_Rest;
    UPROPERTY(meta = (BindWidgetOptional)) class UTextBlock* Txt_RestCount;

    UPROPERTY(meta = (BindWidgetOptional)) class UTextBlock* Txt_SwordTraining;
    UPROPERTY(meta = (BindWidgetOptional)) class UTextBlock* Txt_SwordTrainingCount;

    UPROPERTY(meta = (BindWidgetOptional)) class UTextBlock* Txt_MagicPractice;
    UPROPERTY(meta = (BindWidgetOptional)) class UTextBlock* Txt_MagicPracticeCount;

    UPROPERTY(meta = (BindWidgetOptional)) class UTextBlock* Txt_MagicStudy;
    UPROPERTY(meta = (BindWidgetOptional)) class UTextBlock* Txt_MagicStudyCount;

private:
    // ���� ��
    int32 RemainingTurns = 15;

    // �ؽ�Ʈ ����
    void RefreshTurnText();

    // ��ư Ŭ�� �̺�Ʈ
    UFUNCTION() void OnEquipBuyClicked();
    UFUNCTION() void OnRepairClicked();
    UFUNCTION() void OnRestClicked();
    UFUNCTION() void OnSwordTrainingClicked();
    UFUNCTION() void OnMagicPracticeClicked();
    UFUNCTION() void OnMagicStudyClicked();
};
