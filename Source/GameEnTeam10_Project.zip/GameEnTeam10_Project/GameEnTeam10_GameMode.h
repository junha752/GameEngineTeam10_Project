// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/GameModeBase.h"
#include "GameEnTeam10_GameMode.generated.h"

/**
 * 
 */
UCLASS()
class GAMEENTEAM10_PROJECT_API AGameEnTeam10_GameMode : public AGameModeBase
{
	GENERATED_BODY()
	
};
